package com.fbiego.ota.data

class BtDevice (
        var name: String,
        var address: String,
        var bonded: Boolean
        )